<div class="row-fluid">
    <div id="footer" class="span12">Copyright ©2020 Imobiliare 3D</div>
</div>