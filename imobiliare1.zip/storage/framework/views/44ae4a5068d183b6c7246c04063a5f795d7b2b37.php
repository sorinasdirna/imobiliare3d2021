<?php $__env->startSection('banner'); ?>
	<div class="panel panel--banner dark">
		<div class="slider slider--hero">
			<div class="slider_image" style="background-image: url(<?php echo e(asset('img/slider/slider3.jpg')); ?>)"></div>
			<div class="slider_image" style="background-image: url(<?php echo e(asset('img/slider/slider2.jpg')); ?>)"></div>
			<div class="slider_image" style="background-image: url(<?php echo e(asset('img/slider/slider1.jpg')); ?>)"></div>
		</div>
		<div class="banner-container">
			<div class="banner-text text-center">
				<h1>Gaseste Casa Visurilor Tale</h1>
				<p>La cele mai mici preturi</p>
			</div>
			<div class="search search--home">
				<div class="search-form">
					<form action="<?php echo e(route('anunturi')); ?>" method="get" class=""> 
						<?php echo e(csrf_field()); ?>

						<!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">  -->
						<div class="form-group">
							<div class="form-input form-input--location">           
								<label class="form-label sr-only">Locatie</label>
								<input placeholder="Locatie"  type="text" name="address" class="input">
							</div>
							<div class="form-input form-input--category"> 
								<label class="form-label sr-only">Categorie</label>                              
								<select name="category" class="dropdown">
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="form-input form-input--type">    
								<label class="form-label sr-only">Tip</label>                              
								<select name="type" class="dropdown">
									<option value="sale" selected="selected">De vânzare</option>
									<option value="rent">De închiriat</option>
								</select>                                    
							</div>
							<div class="form-input form-input--submit">  
								<input type="submit" class="button button--search" value="Caută">
							</div>    
						</div>    
					</form>
				</div>
			</div>
		</div>
		<div id="skip" class="banner-skip">
			<i class="fa fa-angle-double-down"></i>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="panel--content">
		<main id="main">
			<section class="section section--overview">
				<div class="wrap">
					<h2 class="section-title text-center">Valorile noastre</h2>
					<div class="text-center slider-container">
						<div class="slider-item">
							<div class="item">
								<img src="<?php echo e(asset('img/svg/value1.svg')); ?>" alt="icon 1">
								<h4>Profesionalism</h4>
								<p>Oferim cele mai inalte standarde etice, respectam angajamentele si promisiunile noastre.</p>
							</div>
						</div>
						<div class="slider-item">
							<div class="item">
								<img src="<?php echo e(asset('img/svg/value1.svg')); ?>" alt="icon 1">
								<h4>Calitate</h4>
								<p>Ne propunem sa depasim asteptarile in tot ceea ce facem.</p>
							</div>
						</div>
						<div class="slider-item">
							<div class="item">
								<img src="<?php echo e(asset('img/svg/value1.svg')); ?>" alt="icon 1">
								<h4>Integritate</h4>
								<p>Ne concentram pe o comunicare onesta, oferim oportunitati si stabilitate pe termen lung in care increderea este primara.</p>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section class="section section--properties">
				<div class="wrap">
					<h2 class="section-title text-center">Cele mai recente</h2>
					<div class="slider-container">
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($product->p_status==1): ?>
						<div class="slider-item">
							<div class="property">
								<div class="property_wrap">
									<div class="property_top">
										<div class="property_image" style="background-image: url(<?php echo e(url('products',$product->image)); ?>)"></div>
										<div class="property_type"><?php echo e(($product->p_type=='rent')?'De inchiriat':'De vanzare'); ?></div>
										<div class="property_price"><?php echo e($product->p_price); ?> <?php echo e($product->p_currency); ?></div>
									</div>
									<div class="property_bottom">
										<div class="property_category"><?php echo e($product->category->name); ?></div>
										<div class="property_title"><?php echo e($product->p_name); ?></div>
										<div class="property_location"><i class="fa fa-map-marker"></i> <?php echo e($product->p_address); ?></div>
										<div class="property_more">
											<a href="<?php echo e(url('detalii', [$product->id])); ?>" class="button">Detalii Anunt</a>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php endif; ?>
					    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="text-center">
						<a href="<?php echo e(url('anunturi')); ?>" class="button button--dark">Vezi toate anunturile</a>
					</div>
				</div>
			</section>
			<section class="section section--categories">
				<div class="wrap">
					<h2 class="section-title text-center">Categorii</h2>
					<div class="slider-container">
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="slider-item">
							<div class="category">
								<div class="category_wrap">
									<div class="category_top">
										<div class="category_image" style="background-image: url(<?php echo e(url('categories',$category->image)); ?>)"></div>
									</div>
									<div class="category_bottom">
										<div class="category_title"><?php echo e($category->name); ?></div>
										<div class="category_more">
											<a href="<?php echo e(url('categorii', [$category->id])); ?>" class="button">Vezi toate</a>
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</section>
			<section class="section section--video">
				<div class="video">
					<video autoplay muted loop>
					    <source src="<?php echo e(asset('video/home-video.mp4')); ?>" type="video/mp4">
					</video>
				</div>
				<div class="video-text dark text-center">
					<div class="wrap">
						<h2 class="title">Despre noi</h2>
						<p>Anim et cupidatat in velit occaecat aute quis quis in pariatur laborum quis ut consectetur.</p>
						<a class="button button--dark" href="<?php echo e(url('contact')); ?>">Contacteaza-ne</a>
					</div>
				</div>
			</section>
		</main>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>