<?php $__env->startSection('title','List Products'); ?>
<?php $__env->startSection('content'); ?>
    <div id="breadcrumb"> <a href="<?php echo e(url('/admin')); ?>" title="Mergi la prima pagina" class="tip-bottom"><i class="icon-home"></i> Acasa</a> <a href="<?php echo e(route('product.index')); ?>" class="current">Anunturi</a></div>
    <div class="container-fluid">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <strong>Well done!</strong> <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="widget-box">
            <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                <h5>Anunturi</h5>
            </div>
            <div class="widget-content nopadding">
                <div class="table-wrap">
                    <table class="table table-bordered data-table">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Cod intern</th>
                            <th>Imagine</th>
                            <th>Nume</th>
                            <th>Categorie</th>
                            <th>Pret</th>
                            <th>Data creare</th>
                            <th>Data ultima editare</th>
                            <th>Status</th>
                            <th>Galerie</th>
                            <th>Actiuni</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++; ?>
                                <tr class="gradeC">
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($product->p_code); ?></td>
                                    <td><img src="<?php echo e(url('products',$product->image)); ?>" alt="" width="50"></td>
                                    <td><?php echo e($product->p_name); ?></td>
                                    <td><?php echo e($product->category->name); ?></td>
                                    <td><?php echo e($product->p_price); ?> <?php echo e($product->p_currency); ?></td>
                                    <td><?php echo e($product->created_at->diffForHumans()); ?></td>
                                    <td><?php echo e($product->updated_at->diffForHumans()); ?></td>
                                    <td><?php echo e(($product->p_status==0)?'Inactiv':'Activ'); ?></td>
                                    <td><a href="<?php echo e(route('image-gallery.show',$product->id)); ?>" class="btn btn-default btn-mini">Adauga imagini</a></td>
                                    <td>
                                        <a href="#myModal<?php echo e($product->id); ?>" data-toggle="modal" class="btn btn-info btn-mini">Vezi</a>
                                        <a href="<?php echo e(route('product.edit',$product->id)); ?>" class="btn btn-primary btn-mini">Editeaza</a>
                                        <a href="javascript:" rel="<?php echo e($product->id); ?>" rel1="delete-product" class="btn btn-danger btn-mini deleteRecord">Sterge</a>
                                    </td>
                                    
                                    <div id="myModal<?php echo e($product->id); ?>" class="modal hide">
                                        <div class="modal-header">
                                            <button data-dismiss="modal" class="close" type="button">×</button>
                                            <h3><?php echo e($product->p_code); ?> - <?php echo e($product->p_name); ?></h3>
                                        </div>
                                        <div class="modal-body">
                                            <div><img src="<?php echo e(url('products',$product->image)); ?>" width="100" alt="<?php echo e($product->p_code); ?>"></div>
                                            <p><?php echo $product->p_description; ?></p>
                                            <h4>Detalii anunt: </h4>
                                            <ul>
                                                <li>
                                                    <strong>Adresa: </strong>
                                                    <span><?php echo e($product->p_address); ?> <?php echo e($product->p_neighborhood); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Status: </strong>
                                                    <span><?php echo e(($product->p_status==0)?'Inactiv':'Activ'); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Categorie: </strong>
                                                    <span><?php echo e($product->category->name); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Tip: </strong>
                                                    <span><?php echo e(($product->p_type=='sale')?'De vanzare':'De inchiriat'); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Pret: </strong>
                                                    <span><?php echo e($product->p_price); ?> <?php echo e($product->p_currency); ?> 
                                                        <?php if($product->p_pricemp2): ?>(<?php echo e($product->p_pricemp2); ?> <?php echo e($product->p_currency); ?> mp<sup>2</sup>)<?php endif; ?>
                                                        <?php if($product->p_negotiable == 1): ?> negociabil <?php endif; ?> 
                                                    </span>
                                                </li>
                                                <li>
                                                    <strong>Numar camere: </strong>
                                                    <span><?php echo e($product->p_rooms); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Numar bai: </strong>
                                                    <span><?php echo e($product->p_baths); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Numar balcoane: </strong>
                                                    <span><?php echo e($product->p_balconies); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Numar holuri: </strong>
                                                    <span><?php echo e($product->p_hallways); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Tip locuinta: </strong>
                                                    <span><?php echo e($product->p_typeof); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Mobila: </strong>
                                                    <span><?php echo e($product->p_furniture); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Material constructie: </strong>
                                                    <span><?php echo e($product->p_material); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Etaj: </strong>
                                                    <span><?php echo e($product->p_floor); ?> <?php echo e(($product->p_totalfloors=='')?'':'din'); ?> <?php echo e($product->p_totalfloors); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Suprafata totala: </strong>
                                                    <span><?php echo e($product->p_totalsurface); ?> mp<sup>2</sup> 
                                                        <?php if($product->p_usablesurface): ?>(Disponibila: <?php echo e($product->p_usablesurface); ?> mp<sup>2</sup>)<?php endif; ?>
                                                    </span>
                                                </li>
                                                <li>
                                                    <strong>An constructie: </strong>
                                                    <span><?php echo e($product->p_year); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Stare constructie: </strong>
                                                    <span><?php echo e($product->p_condition); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Cadastru: </strong>
                                                    <span><?php echo e(($product->p_cadastre=='0')?'Da':'Nu'); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Intabulare: </strong>
                                                    <span><?php echo e(($product->p_tabulate=='0')?'Da':'Nu'); ?></span>
                                                </li>
                                            </ul>
                                            <h4>Detalii client:</h4>
                                            <ul>
                                                <li>
                                                    <strong>Nume: </strong>
                                                    <span><?php echo e($product->p_clientname); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Telefon: </strong>
                                                    <span><?php echo e($product->p_clientphone); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Adresa: </strong>
                                                    <span><?php echo e($product->p_clientaddress); ?></span>
                                                </li>
                                                <li>
                                                    <strong>Descriere: </strong>
                                                    <span><?php echo e($product->p_clientdescription); ?></span>
                                                </li>
                                            </ul>
                                            <h4>Detalii SEO:</h4>
                                            <ul>
                                                <li>
                                                    <strong>Cuvinte cheie: </strong> 
                                                    <span><?php echo e($product->p_seokeys); ?></span>
                                                </li>
                                                <li><strong>Descriere: </strong>
                                                    <span><?php echo e($product->p_seodescription); ?></span>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.tables.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.popover.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <script>
        $(".deleteRecord").click(function () {
            var id=$(this).attr('rel');
            var deleteFunction=$(this).attr('rel1');
            swal({
                title:'Esti sigur ca vrei sa stergi anuntul?',
                text:"",
                type:'warning',
                showCancelButton:true,
                confirmButtonColor:'#3085d6',
                cancelButtonColor:'#d33',
                confirmButtonText:'Da',
                cancelButtonText:'Nu',
                confirmButtonClass:'btn btn-success',
                cancelButtonClass:'btn btn-danger',
                buttonsStyling:false,
                reverseButtons:true
            },function () {
                window.location.href="/admin/"+deleteFunction+"/"+id;
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>