<?php $__env->startSection('banner'); ?>
	<div class="panel panel--banner">
		<div class="page-title page-title--sale dark">
			<div class="banner-container">
	
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="panel--content">
		<main id="main">
			<section class="section section--properties-listing">
				<div class="wrap">
					<h2 class="title text-center"><?php echo e($category->name); ?></h2>
					<div class="grid">
						<div class="grid_col grid_col--3-of-4 grid_col--md-1-of-1">
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  						<?php if($product->p_status==1): ?>
			  						<?php if($product->category->status==1): ?>
										<div class="property">
											<div class="property_wrap">
												<div class="property_left">
													<div class="property_image" style="background-image: url(<?php echo e(url('products',$product->image)); ?>)"></div>
													<div class="property_type"><?php echo e(($product->p_type=='rent')?'De inchiriat':'De vanzare'); ?></div>
													<div class="property_price"><?php echo e($product->p_price); ?> <?php echo e($product->p_currency); ?></div>
												</div>
												<div class="property_right">
													<div class="property_category"><?php echo e($product->category->name); ?></div>
													<div class="property_title"><?php echo e($product->p_name); ?></div>
													<div class="property_surface">Suprafata totala: <?php echo e($product->p_totalsurface); ?>mp<sup>2</sup></div>
													<div class="property_location"><i class="fa fa-map-marker"></i> <?php echo e($product->p_address); ?></div>
													<div class="property_more">
														<a href="<?php echo e(url('detalii', [$product->id])); ?>" class="button">Detalii</a>
													</div>
												</div>
											</div>
										</div>
									<?php endif; ?>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="categories-accordion grid_col grid_col--1-of-4 grid_col--md-1-of-1">
						    <div class="accordion">
						    	<h3>Categorii:</h3>
							    <?php
							        $categories=DB::table('categories')->where([['status',1]])->get();
							    ?>
						        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						            <?php
						                $sub_categories=DB::table('categories')->select('id','name')->where([['parent_id',$category->id],['status',1]])->get();
						            ?>
						            <div class="accordion_item">
					                    <div class="accordion_toggle">
					                        <a href="<?php echo e(url('categorii/'.$category->id)); ?>"><?php echo e($category->name); ?></a>
				                            <?php if(count($sub_categories)>0): ?>
				                                <span class="toggle"><i class="fa fa-plus"></i></span>
				                            <?php endif; ?>
										</div>
						                <?php if(count($sub_categories)>0): ?>
						                    <div class="accordion_collapse">
					                            <ul>
					                                <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					                                    <li><a href="<?php echo e(url('categorii/'.$sub_category->id)); ?>"><?php echo e($sub_category->name); ?> </a></li>
					                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					                            </ul>
						                    </div>
						                <?php endif; ?>
						            </div>
						        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						    </div><!--/category-->
						</div>
					</div>
				</div>
			</section>
		</main>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>