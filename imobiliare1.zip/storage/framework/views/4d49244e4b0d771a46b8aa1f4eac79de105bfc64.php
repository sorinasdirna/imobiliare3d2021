<?php $__env->startComponent('mail::message'); ?>

# Mesajul a fost trimis!<br>

<strong>Nume</strong> <?php echo e($data['name']); ?><br>
<strong>Email</strong> <?php echo e($data['email']); ?><br>
<strong>Mesaj</strong> <?php echo e($data['message']); ?><br>

Va vom contacta in cel mai scurt timp posibil.<br>

Va multumim,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
