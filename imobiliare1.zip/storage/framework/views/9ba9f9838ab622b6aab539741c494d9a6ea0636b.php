<?php $__env->startSection('title','Add Products Page'); ?>
<?php $__env->startSection('content'); ?>
    <div id="breadcrumb"> <a href="<?php echo e(url('/admin')); ?>" title="Mergi la prima pagina" class="tip-bottom"><i class="icon-home"></i> Acasa</a> <a href="<?php echo e(route('product.index')); ?>">Anunturi</a> <a href="<?php echo e(route('product.create')); ?>" class="current">Adauga anunt nou</a> </div>
    <div class="container-fluid">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <strong>Well done! &nbsp;</strong><?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="widget-box">
            <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                <h5>Adauga anunt nou</h5>
            </div>
            <div class="widget-content nopadding">
                <form action="<?php echo e(route('product.store')); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="control-wrap-outer">
                        <h3 class="section-title">Detalii:</h3>
                        <div class="control-wrap-inner">
                            <div class="control-group">
                                <label for="p_name" class="control-label">Nume: </label>
                                <div class="controls<?php echo e($errors->has('p_name')?' has-error':''); ?>">
                                    <input type="text" name="p_name" id="p_name" class="form-control" value="<?php echo e(old('p_name')); ?>" title="" required="required" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_name')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_code" class="control-label">Cod intern: </label>
                                <div class="controls<?php echo e($errors->has('p_code')?' has-error':''); ?>">
                                    <input type="text" name="p_code" id="p_code" class="form-control" value="<?php echo e(old('p_code')); ?>" title="" required="required" style="width: 400px;">
                                    <span class="text-danger" id="chProduct_code"><?php echo e($errors->first('p_code')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Selecteaza categoria: </label>
                                <div class="controls">
                                    <select name="categories_id" style="width: 415px;">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php
                                                if($key!=0){
                                                    $sub_categories=DB::table('categories')->select('id','name')->where('parent_id',$key)->get();
                                                    if(count($sub_categories)>0){
                                                        foreach ($sub_categories as $sub_category){
                                                            echo '<option value="'.$sub_category->id.'">&nbsp;&nbsp;--'.$sub_category->name.'</option>';
                                                        }
                                                    }
                                                }
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Selecteaza tipul: </label>
                                <div class="controls">
                                    <select name="p_type" style="width: 415px;">
                                            <option value="sale">De vanzare</option>
                                            <option value="rent">De inchiriat</option>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group<?php echo e($errors->has('status')?' has-error':''); ?>">
                                <label class="control-label">Activ :</label>
                                <div class="controls">
                                    <input type="checkbox" name="p_status" id="p_status" value="1">
                                    <span class="text-danger"><?php echo e($errors->first('p_status')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Imagine: </label>
                                <div class="controls">
                                    <input type="file" name="image" id="image"/>
                                    <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_description" class="control-label">Descriere: </label>
                                <div class="controls<?php echo e($errors->has('p_description')?' has-error':''); ?>">
                                    <textarea class="textarea_editor span12" name="p_description" id="p_description" rows="6" placeholder="" style="width: 580px;"><?php echo e(old('p_description')); ?></textarea>
                                    <span class="text-danger"><?php echo e($errors->first('p_description')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_price" class="control-label">Pret: </label>
                                <div class="controls<?php echo e($errors->has('p_price')?' has-error':''); ?>">
                                    <div class="input-prepend"> <span class="add-on">$</span>
                                        <input type="number" name="p_price" id="p_price" class="" value="<?php echo e(old('p_price')); ?>" title="">
                                        <span class="text-danger"><?php echo e($errors->first('p_price')); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_pricemp2" class="control-label">Pret/mp<sup>2</sup>: </label>
                                <div class="controls<?php echo e($errors->has('p_pricemp2')?' has-error':''); ?>">
                                    <div class="input-prepend"> <span class="add-on">$</span>
                                        <input type="number" name="p_pricemp2" id="p_pricemp2" class="" value="<?php echo e(old('p_pricemp2')); ?>" title="">
                                        <span class="text-danger"><?php echo e($errors->first('p_pricemp2')); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label">Moneda: </label>
                                <div class="controls">
                                    <select name="p_currency" style="width: 415px;">
                                            <option value="lei">Lei</option>
                                            <option value="euro">Euro</option>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group<?php echo e($errors->has('status')?' has-error':''); ?>">
                                <label class="control-label">Negociabil: </label>
                                <div class="controls">
                                    <input type="checkbox" name="p_negotiable" id="p_negotiable" value="1">
                                    <span class="text-danger"><?php echo e($errors->first('p_negotiable')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_rooms" class="control-label">Numar camere: </label>
                                <div class="controls<?php echo e($errors->has('p_rooms')?' has-error':''); ?>">
                                    <input type="number" name="p_rooms" id="p_rooms" class="form-control" value="<?php echo e(old('p_rooms')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_rooms')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_baths" class="control-label">Numar bai: </label>
                                <div class="controls<?php echo e($errors->has('p_baths')?' has-error':''); ?>">
                                    <input type="number" name="p_baths" id="p_baths" class="form-control" value="<?php echo e(old('p_baths')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_baths')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_balconies" class="control-label">Numar balcoane: </label>
                                <div class="controls<?php echo e($errors->has('p_balconies')?' has-error':''); ?>">
                                    <input type="number" name="p_balconies" id="p_balconies" class="form-control" value="<?php echo e(old('p_balconies')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_balconies')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_hallways" class="control-label">Numar holuri: </label>
                                <div class="controls<?php echo e($errors->has('p_hallways')?' has-error':''); ?>">
                                    <input type="number" name="p_hallways" id="p_hallways" class="form-control" value="<?php echo e(old('p_hallways')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_hallways')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_typeof" class="control-label">Tip locuinta: </label>
                                <div class="controls<?php echo e($errors->has('p_typeof')?' has-error':''); ?>">
                                    <input type="text" name="p_typeof" id="p_typeof" class="form-control" value="<?php echo e(old('p_typeof')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_typeof')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_furniture" class="control-label">Mobila: </label>
                                <div class="controls<?php echo e($errors->has('p_furniture')?' has-error':''); ?>">
                                    <input type="text" name="p_furniture" id="p_furniture" class="form-control" value="<?php echo e(old('p_furniture')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_furniture')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_material" class="control-label">Material constructie: </label>
                                <div class="controls<?php echo e($errors->has('p_material')?' has-error':''); ?>">
                                    <input type="text" name="p_material" id="p_material" class="form-control" value="<?php echo e(old('p_material')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_material')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_floor" class="control-label">Etaj: </label>
                                <div class="controls<?php echo e($errors->has('p_floor')?' has-error':''); ?>">
                                    <input type="text" name="p_floor" id="p_floor" class="form-control" value="<?php echo e(old('p_floor')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_floor')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_totalfloors" class="control-label">Total etaje: </label>
                                <div class="controls<?php echo e($errors->has('p_totalfloors')?' has-error':''); ?>">
                                    <input type="text" name="p_totalfloors" id="p_totalfloors" class="form-control" value="<?php echo e(old('p_totalfloors')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_totalfloors')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_totalsurface" class="control-label">Suprafata totala( mp<sup>2</sup>): </label>
                                <div class="controls<?php echo e($errors->has('p_totalsurface')?' has-error':''); ?>">
                                    <input type="text" name="p_totalsurface" id="p_totalsurface" class="form-control" value="<?php echo e(old('p_totalsurface')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_totalsurface')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_usablesurface" class="control-label">Suprafata disponibila( mp<sup>2</sup>): </label>
                                <div class="controls<?php echo e($errors->has('p_usablesurface')?' has-error':''); ?>">
                                    <input type="text" name="p_usablesurface" id="p_usablesurface" class="form-control" value="<?php echo e(old('p_usablesurface')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_usablesurface')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_year" class="control-label">An constructie: </label>
                                <div class="controls<?php echo e($errors->has('p_year')?' has-error':''); ?>">
                                    <input type="text" name="p_year" id="p_year" class="form-control" value="<?php echo e(old('p_year')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_year')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_condition" class="control-label">Conditie constructie: </label>
                                <div class="controls<?php echo e($errors->has('p_condition')?' has-error':''); ?>">
                                    <input type="text" name="p_condition" id="p_condition" class="form-control" value="<?php echo e(old('p_condition')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_condition')); ?></span>
                                </div>
                            </div>
                            <div class="control-group<?php echo e($errors->has('status')?' has-error':''); ?>">
                                <label class="control-label">Cadastru: </label>
                                <div class="controls">
                                    <input type="checkbox" name="p_cadastre" id="p_cadastre" value="1">
                                    <span class="text-danger"><?php echo e($errors->first('p_cadastre')); ?></span>
                                </div>
                            </div>
                            <div class="control-group<?php echo e($errors->has('status')?' has-error':''); ?>">
                                <label class="control-label">Intabulare:</label>
                                <div class="controls">
                                    <input type="checkbox" name="p_tabulate" id="p_tabulate" value="1">
                                    <span class="text-danger"><?php echo e($errors->first('p_tabulate')); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="control-wrap-outer">
                        <h3 class="section-title">Adresa:</h3>
                        <div class="control-wrap-inner">
                            <div class="control-group">
                                <div class="controls<?php echo e($errors->has('p_address')?' has-error':''); ?>">
                                    <input type="text" name="p_address" id="searchInput" class="form-control" value="<?php echo e(old('p_address')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_address')); ?></span>
                                </div>
                            </div>
                            <div class="map" id="map" style="width: 100%; height: 300px;"></div>
                            <div class="control-group">
                                <label for="p_address" class="control-label">Adresa: </label>
                                <div class="controls<?php echo e($errors->has('p_address')?' has-error':''); ?>">
                                    <input type="text" name="p_address" id="location" class="form-control" value="<?php echo e(old('p_address')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_address')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_addresslat" class="control-label">Latitudine: </label>
                                <div class="controls<?php echo e($errors->has('p_addresslat')?' has-error':''); ?>">
                                    <input type="text" name="p_addresslat" id="lat" class="form-control" value="<?php echo e(old('p_addresslat')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_addresslat')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_addresslon" class="control-label">Longitudine: </label>
                                <div class="controls<?php echo e($errors->has('p_addresslon')?' has-error':''); ?>">
                                    <input type="text" name="p_addresslon" id="lng" class="form-control" value="<?php echo e(old('p_addresslon')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_addresslon')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_neighborhood" class="control-label">Cartier: </label>
                                <div class="controls<?php echo e($errors->has('p_neighborhood')?' has-error':''); ?>">
                                    <input type="text" name="p_neighborhood" id="p_neighborhood" class="form-control" value="<?php echo e(old('p_neighborhood')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_neighborhood')); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="control-wrap-outer">
                        <h3 class="section-title">SEO:</h3>
                        <div class="control-wrap-inner">
                            <div class="control-group">
                                <label for="p_seokeys" class="control-label">Cuvinte SEO (Ex: cuv1, cuv2...max10 cuvinte): </label>
                                <div class="controls<?php echo e($errors->has('p_seokeys')?' has-error':''); ?>">
                                    <input type="text" name="p_seokeys" id="p_seokeys" class="form-control" value="<?php echo e(old('p_seokeys')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_seokeys')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_seodescription" class="control-label">Descriere SEO: </label>
                                <div class="controls<?php echo e($errors->has('p_seodescription')?' has-error':''); ?>">
                                    <textarea class=" span12" name="p_seodescription" id="p_seodescription" rows="6" placeholder="" style="width: 580px;"><?php echo e(old('p_seodescription')); ?></textarea>
                                    <span class="text-danger"><?php echo e($errors->first('p_seodescription')); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="control-wrap-outer">
                        <h3 class="section-title">Client:</h3>
                        <div class="control-wrap-inner">
                            <div class="control-group">
                                <label for="p_clientname" class="control-label">Nume Client: </label>
                                <div class="controls<?php echo e($errors->has('p_clientname')?' has-error':''); ?>">
                                    <input type="text" name="p_clientname" id="p_clientname" class="form-control" value="<?php echo e(old('p_clientname')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_clientname')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_clientphone" class="control-label">Telefon client: </label>
                                <div class="controls<?php echo e($errors->has('p_clientphone')?' has-error':''); ?>">
                                    <input type="text" name="p_clientphone" id="p_clientphone" class="form-control" value="<?php echo e(old('p_clientphone')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_clientphone')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_clientaddress" class="control-label">Adresa client: </label>
                                <div class="controls<?php echo e($errors->has('p_clientaddress')?' has-error':''); ?>">
                                    <input type="text" name="p_clientaddress" id="p_clientaddress" class="form-control" value="<?php echo e(old('p_clientaddress')); ?>" title="" style="width: 400px;">
                                    <span class="text-danger"><?php echo e($errors->first('p_clientaddress')); ?></span>
                                </div>
                            </div>
                            <div class="control-group">
                                <label for="p_clientdescription" class="control-label">Descriere client: </label>
                                <div class="controls<?php echo e($errors->has('p_clientdescription')?' has-error':''); ?>">
                                    <textarea class=" span12" name="p_clientdescription" id="p_clientdescription" rows="6" placeholder="" style="width: 580px;"><?php echo e(old('p_clientdescription')); ?></textarea>
                                    <span class="text-danger"><?php echo e($errors->first('p_clientdescription')); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="control-wrap-outer">
                        <div class="control-wrap-inner">
                            <div class="control-group">
                                <label for="" class="control-label"></label>
                                <div class="controls">
                                    <button type="submit" class="btn btn-success">Adauga</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('jsblock'); ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.ui.custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.uniform.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.validate.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.form_validation.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.tables.js')); ?>"></script>
    <script src="<?php echo e(asset('js/matrix.popover.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wysihtml5-0.3.0.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-wysihtml5.js')); ?>"></script>
    <script>
        $('.textarea_editor').wysihtml5();
    </script>

    <!--load google api-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBNsGMkm0logdWbHDjTSDHS2kSEx9GBPNM&libraries=places"></script>
    <script type="text/javascript">
        /************GOOGLE MAP*******/
        function initialize() {
           var latlng = new google.maps.LatLng(<?php if(!empty($latdb)) echo $latdb; else echo '44.3301785'; ?>, <?php if(!empty($lngdb)) echo $lngdb; else echo'23.79488070000002'; ?>);
            var map = new google.maps.Map(document.getElementById('map'), {
              center: latlng,
              zoom: 13
            });
            var marker = new google.maps.Marker({
              map: map,
              position: latlng,
              draggable: false,
              anchorPoint: new google.maps.Point(0, -29)
           });
            var input = document.getElementById('searchInput');
            map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
            var geocoder = new google.maps.Geocoder();
            var autocomplete = new google.maps.places.Autocomplete(input);
            autocomplete.bindTo('bounds', map);
            var infowindow = new google.maps.InfoWindow();   
            autocomplete.addListener('place_changed', function() {
                infowindow.close();
                marker.setVisible(false);
                var place = autocomplete.getPlace();
                if (!place.geometry) {
                    window.alert("Autocomplete's returned place contains no geometry");
                    return;
                }
          
                // If the place has a geometry, then present it on a map.
                if (place.geometry.viewport) {
                    map.fitBounds(place.geometry.viewport);
                } else {
                    map.setCenter(place.geometry.location);
                    map.setZoom(17);
                }
               
                marker.setPosition(place.geometry.location);
                marker.setVisible(true);          
            
                bindDataToForm(place.formatted_address,place.geometry.location.lat(),place.geometry.location.lng());
                infowindow.setContent(place.formatted_address);
                infowindow.open(map, marker);
               
            });
            // this function will work on marker move event into map 
            google.maps.event.addListener(marker, 'dragend', function() {
                geocoder.geocode({'latLng': marker.getPosition()}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                  if (results[0]) {        
                      bindDataToForm(results[0].formatted_address,marker.getPosition().lat(),marker.getPosition().lng());
                      infowindow.setContent(results[0].formatted_address);
                      infowindow.open(map, marker);
                  }
                }
                });
            });
        }
        function bindDataToForm(address,lat,lng){
           document.getElementById('location').value = address;
           document.getElementById('lat').value = lat;
           document.getElementById('lng').value = lng;
        }
        google.maps.event.addDomListener(window, 'load', initialize);
        /*****END MAP****/


        // GMap
        $('#map').click(function () {
            $('#map iframe').css("pointer-events", "auto");
        });
        
        $( "#map" ).mouseleave(function() {
          $('#map iframe').css("pointer-events", "none"); 
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>