<?php $__env->startSection('banner'); ?>
	<div class="panel panel--banner">
		<div class="page-title page-title--contact dark">
			<div class="banner-container">
				<h1>Contact</h1>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="panel--content">
		<main id="main">
			<section class="section section--contact">
				<div class="wrap">
					<div class="form-info">
						<p>Pentru informatii suplimentare va rugam sa ne contactati completand campurile din formularul de mai jos. 
							<br>Campurile marcate cu <span class="required">*</span> sunt obligatorii.</p>
					</div>
					
					<?php if(session()->has('message_success')): ?>
				    	<div class="success"><?php echo e(session()->get('message_success')); ?></div>
					<?php else: ?>
						<?php if( ! session()->has('message')): ?>
					        <form action="/contact" method="POST">
					        	<div class="form-group">
						            <div class="form-input form-input--name">
						                <label for="name">Nume <span class="required">*</span></label>
						                <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="input">
						                <div class="error"><?php echo e($errors->first('name')); ?></div>
						            </div>

					            <div class="form-input form-input--email">
					                <label for="email">Email <span class="required">*</span></label>
					                <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="input">
					                <div class="error"><?php echo e($errors->first('email')); ?></div>
					            </div>

					            <div class="form-input form-input--message">
					                <label for="message">Mesaj <span class="required">*</span></label>
					                <textarea name="message" id="message" cols="30" rows="10"
					                          class="input"><?php echo e(old('message')); ?></textarea>
					                <div class="error"><?php echo e($errors->first('message')); ?></div>
					            </div>

					            <?php echo csrf_field(); ?>

								 <div class="form-input form-input--submit">
						            <button type="submit" class="button button--contact">Trimite Mesaj</button>
								</div>
					        </form>
					    <?php endif; ?>
					<?php endif; ?>
				</div>
			</section>
		</main>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>