<!--Header-part-->
<div id="header">
    <a href="<?php echo e(url('/')); ?>" target="_blank">
        <img src="<?php echo e(asset('img/logo.png')); ?>" alt="Logo">
    </a>
</div>
<!--close-Header-part-->
<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
    <ul class="nav">
        <li class=""><a title="" href="<?php echo e(url('/admin/settings')); ?>"><i class="icon icon-cog"></i> <span class="text">Setari cont</span></a></li>
        <li class="">
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                <i class="icon icon-share-alt"></i><span class="text">Deconectare</span>
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>

        </li>
    </ul>
</div>
<!--close-top-Header-menu-->